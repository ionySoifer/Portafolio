import React from 'react';
import { Link } from 'react-router-dom';
import '../App.css';

const Contacto = () => {
 
    return (
     
   <>
  <div className="row align-items-center justify-content-between flex-column flex-sm-row border-top pb-5">
        <div className="bg-light rounded-4 py-5 px-4 px-md-5">
        <div className="text-center mb-5">
            <div className="feature bg-primary bg-gradient-primary-to-secondary text-white rounded-3 mb-3"><i className="bi-envelope"></i></div>
            <h1 className="fw-bolder">Contacto</h1>
        </div>
        <div className="row gx-5 justify-content-center">
            <div className="col-lg-8 col-xl-6">
    
                <form id="contactForm" data-sb-form-api-token="API_TOKEN">
                    
                    <div className="form-floating mb-3">
                        <input className="form-control" id="name" type="text" placeholder="Enter your name..." data-sb-validations="required" />
                        <label for="name">Nombre completo</label>
                    </div>
                   
                    <div className="form-floating mb-3">
                        <input className="form-control" id="email" type="email" placeholder="name@example.com" data-sb-validations="required,email" />
                        <label for="email">Email </label>
                    </div>
                  
                    <div className="form-floating mb-3">
                        <input className="form-control" id="phone" type="tel" placeholder="(123) 456-7890" data-sb-validations="required" />
                        <label for="phone">Numero de telefono</label>
                    </div>
                   
                    <div className="form-floating mb-3">
                        <textarea className="form-control altura" id="message" type="text" placeholder="Enter your message here..."  data-sb-validations="required"></textarea>
                        <label for="message">Mensaje</label>
                    </div>
                   
                    <div className="d-none" id="submitErrorMessage"><div className="text-center text-danger mb-3">Error sending message!</div></div>
                  
                    <div className="d-grid"><button className="btn btn-primary btn-lg disabled" id="submitButton" type="submit">Submit</button></div>
                </form>
            </div>
        </div>
    </div>
    </div>
    </>
    );
};

export default Contacto;